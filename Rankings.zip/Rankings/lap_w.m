function L=lap_w(G)
%Laplacian: edge-weighted graph.
%
A = adjacency(G,'weighted');
n=length(A);
S=sum(A);
D=diag(S);
E=D-A;
e1=eig(E);
e2=e1.^2;
e3=sum(e2);%E_l(G)
L=zeros(n,1);

for i=1:n
    H=G;
    H1=rmnode(H,i);
    A1= adjacency(H1,'weighted');
    S1=sum(A1);
    D1=diag(S1);
    E1=D1-A1;
    e11=eig(E1);
    e21=e11.^2;
    e31=sum(e21);%E_L(G1)
    L(i)=(e3-e31)/e3;
end
end