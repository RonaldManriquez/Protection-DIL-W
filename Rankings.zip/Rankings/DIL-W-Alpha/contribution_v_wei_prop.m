function H= contribution_v_wei_prop(G,alpha)
%Input :A weighted undirected graph 
%output : edge vertex contribution matrix. En la posición h_{ij} está la
%contribución del vertices i a la arista (i,j).
A=adjacency(G,'weighted');
DW=degree_wa(G,alpha);
N=length(DW);
H=zeros(N);
[IMP, IMatrix]=importance_line_wei_prop(G,alpha);
%[sOut,tOut] = findedge(G);
for i=1:N
    for j=1:N
        if i==j
            H(i,j)=0;
        elseif A(i,j)~=0
            H(i,j)= IMatrix(i,j)*(DW(i)-A(i,j)^(alpha))/(DW(i)+DW(j)-2*A(i,j)^(alpha));%original idea IMatrix(i,j)*(DW(i)-(1-alpha))/(DW(i)+DW(j)-2*(1-alpha));
        end     %%%para  alpha=1 queda el peso, para alpha=0 queda el 1 original
    %H(i)=IMatrix(sOut(i),tOut(i))*(D(sOut(i))-1)/(D(sOut(i))+D(tOut(i))-2);
    %W(sOut(i),tOut(i))=H(i);
    end
end
end