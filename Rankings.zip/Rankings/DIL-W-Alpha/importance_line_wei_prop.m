function [IMP,IMatrix]=importance_line_wei_prop(G,alpha)%%%%%%completar!!!!!!
%Input :A weighted undirected graph 
%output : edge importance matrix (IMatrix) and IMP edge importance vector
A=adjacency(G,'weighted');
B=adjacency(G);
C=triangule_coef_edge(B);
S=strength(A);%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%hasta aqui modifiqué!
N=length(S);
DW=degree_wa(G,alpha);
ST=triangule_coef_wei(G);%%%%
E=numedges(G);
IMP=zeros(E,1);
C2=zeros(E,2);
IMatrix=zeros(N);
%P=zeros(E,1);
[sOut,tOut] = findedge(G);

%for k=1:E
 %   P(k)=(C(k)+1)^(1-alpha)*ST(sOut(k),tOut(k))^(alpha);
%end

for j=1:E
    C2(j)=(C(j)^(1-alpha)*(ST(sOut(j),tOut(j))+ST(tOut(j),sOut(j)))^(alpha))/2+1;
end

for i=1:E
    IMP(i)=((DW(sOut(i))-(C(i)+1)^(1-alpha)*ST(tOut(i),sOut(i))^(alpha))*(DW(tOut(i))-(C(i)+1)^(1-alpha)*ST(sOut(i),tOut(i))^(alpha)))/(C2(i));
    IMatrix(sOut(i),tOut(i))=IMP(i);
    IMatrix(tOut(i),sOut(i))=IMP(i);
end
end
