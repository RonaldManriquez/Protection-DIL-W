function DW=degree_wa(G,alpha)
        %G graph
        %alpha constant in [0,1];
        A=adjacency(G,'weighted');
        n=length(A);
        DW=zeros(n,1);
        S=strength(A);
        for i=1:n
        DW(i)=degree(G,i)^(1-alpha)*S(i)^alpha;
        end
end