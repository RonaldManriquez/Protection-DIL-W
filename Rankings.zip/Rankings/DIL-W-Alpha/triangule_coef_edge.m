function C=triangule_coef_edge(A)
%CLUSTERING_COEF_BU     Clustering coefficient
%
%  
%
%   The triangule coefficient is the number of triangles around a edge
%
%   Input:      A,      binary undirected connection matrix
%
%   Output:     C,      triangule coefficient vector
%
%   Reference: Watts and Strogatz (1998) Nature 393:440-442.
%
%  Original from https://sites.google.com/site/bctnet/measures/list
%                           Mika Rubinov, UNSW, 2007-2010
% Modification by Ronald Manríquez, UPLA 2020.

n=length(A);
T=sum(A);
T2=sum(T)/2;
C=zeros(T2,1);
M=zeros(n);
%C2=zeros(T2,1);
r=1;
for u=1:n
    V=find(A(u,:));
    k=length(V);
    if k>=2                 %degree must be at least 2
        %r=k
        S=A(V,V);
        SU=sum(S);
        for i=1:k
            if M(u,V(i))==0 %matriz para controlar  
                C(r)=SU(i);
                M(u,V(i))=1;
                M(V(i),u)=1;
                r=r+1;%%reiniciada correcta
            end
        end
    end
end
end