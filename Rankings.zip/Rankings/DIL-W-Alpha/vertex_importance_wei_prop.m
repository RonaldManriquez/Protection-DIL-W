function L_IM=vertex_importance_wei_prop(G,alpha)
%Input  :G weighted undirected graph; alpha\in[0,1]. 
%output : A vertex importance vector

DW=degree_wa(G,alpha);
N=length(DW);
L_IM=zeros(N,1);
H=contribution_v_wei_prop(G,alpha);
for i=1:N
    NEI=neighbors(G,i);
    M=length(NEI);
    L_IM(i)=DW(i);
    for j=1:M
    L_IM(i)=L_IM(i)+H(i,NEI(j));
    end
end
end