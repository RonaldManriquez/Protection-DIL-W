function ST=triangule_coef_wei(G)
%CLUSTERING_COEF_BU     Clustering coefficient
%
%   C = clustering_coef_bu(A);
%
%   The triangule coefficient is the number of triangles around a node
%
%   Input:      G,      weighted undirected graph
%
%   Output:     ST,      la matriz ST entrega la suma de fuerzas que son incidentes al vertices j. 
%Es decir en la posición a_{ij} está la suma de fuerzas incidentes al
%vertice j que forman un triangulo con el lado e_{ij}.

%
%   Reference: Watts and Strogatz (1998) Nature 393:440-442.
%
%  Original from https://sites.google.com/site/bctnet/measures/list
%                           Mika Rubinov, UNSW, 2007-2010
% Modification by Ronald Manríquez, UPLA 2020.

A=adjacency(G,'weighted');
%E=numedges(G);
n=length(A);
%T=sum(A);
%C=zeros(E,1);
%M=zeros(n);
ST=zeros(n);
%r=1;
%[sOut,tOut] = findedge(G);
for u=1:n
    V=find(A(u,:));
    k=length(V);
    if k>=2                 %degree must be at least 2
        %r=k
        S=A(V,V);
        SU=sum(S);
        for i=1:k
            ST(u,V(i))=SU(i);
            
           % if M(u,V(i))==0 %matriz para controlar  
            %    C(r)=SU(i);
            %    M(u,V(i))=1;
            %    M(V(i),u)=1;
             %   r=r+1;%%reiniciada correcta
            %end
        end
    end
end
end