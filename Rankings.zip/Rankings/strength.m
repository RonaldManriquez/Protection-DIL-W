function ST=strength(A)
%A matriz de adyacencia

n=length(A);
ST=zeros(n,1);
for i=1:n
    ST(i)=sum(A(i,:));
end
end